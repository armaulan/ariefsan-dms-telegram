# FastExcelHelper

Collection of functions for several packages:
* https://github.com/aVadim483/fast-excel-reader
* https://github.com/aVadim483/fast-excel-writer
* https://github.com/aVadim483/fast-excel-templator