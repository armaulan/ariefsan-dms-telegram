<?php

namespace avadim\FastExcelWriter\Interfaces;

interface InterfaceBookWriter
{

}