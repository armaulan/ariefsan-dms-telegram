<?php

namespace avadim\FastExcelWriter\Interfaces;

interface InterfaceSheetWriter
{

}