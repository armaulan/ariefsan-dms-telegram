<?php

namespace avadim\FastExcelWriter\Exceptions;

/**
 * Class Exception
 *
 * @package avadim\FastExcelWriter
 */
class ExceptionRangeName extends Exception
{

}

// EOF