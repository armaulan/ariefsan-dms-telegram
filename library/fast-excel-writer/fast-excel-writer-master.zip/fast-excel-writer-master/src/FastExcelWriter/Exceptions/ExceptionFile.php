<?php

namespace avadim\FastExcelWriter\Exceptions;

/**
 * Class Exception
 *
 * @package avadim\FastExcelWriter
 */
class ExceptionFile extends Exception
{

}

// EOF