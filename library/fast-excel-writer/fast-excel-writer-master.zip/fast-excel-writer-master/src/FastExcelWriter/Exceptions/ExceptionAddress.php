<?php

namespace avadim\FastExcelWriter\Exceptions;

/**
 * Class Exception
 *
 * @package avadim\FastExcelWriter
 */
class ExceptionAddress extends Exception
{

}

// EOF